window['__SCHEMA__'] = {
  "version": "1.0.0",
  "componentsMap": [
    {
      "componentName": "Image"
    },
    {
      "componentName": "Text"
    },
    {
      "componentName": "Layer"
    },
    {
      "componentName": "Page"
    }
  ],
  "componentsTree": [
    {
      "id": "node_0_97r69x6",
      "name": "Screen",
      "componentName": "Page",
      "lifeCycles": {},
      "props": {
        "width": 800,
        "height": 480,
        "backgroundColor": "#060617",
        "gridEnabled": false,
        "gridSize": 50,
        "gridColor": "rgba(255, 255, 255, 0.3)"
      },
      "children": [
        {
          "id": "node_0_r0s0390",
          "name": "Image 1",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 800,
            "height": 480,
            "rotation": "",
            "visible": false,
            "borderColor": "#f53b0d",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 50,
            "objectFit": "contain",
            "left": 0,
            "top": 0,
            "image": "asset://ff5eea07-49a6-4d56-85c6-f1fb72fcd893",
            "___isLocked___": true
          }
        },
        {
          "id": "node_5_knm44hr",
          "name": "Layer 1",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 49,
            "top": 24,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_3_mnbn6dd",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "$scope.bestTime = \"00:00.000\";\n$scope.lastValid = 0;\nfunction format(ms) {\n  if (!Number.isFinite(ms)) return $scope.bestTime;\n  \n  const d = new Date(ms);\n  $scope.lastValid = ms;\n  return `${d.getUTCMinutes().toString().padStart(2,'0')}:` +\n         `${d.getUTCSeconds().toString().padStart(2,'0')}.` +\n         `${d.getUTCMilliseconds().toString().padStart(3,'0')}`;\n}\n\nreturn $scope.bestTime = format($data.bestLapTime);",
                  "mock": "1:54.321"
                },
                "width": 458,
                "height": 108,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 110,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 36,
                "top": 24,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_4_39mpzl2",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "BEST LAP",
                "width": 173,
                "height": 37,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 179,
                "top": 130,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_6_lc5byc4",
          "name": "Layer 2",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 536,
            "top": 20,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_7_svtw4uw",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 强制显示±符号和两位小数（FIA标准格式）\nreturn isNaN($data.gainLoss) ? \"+0.00\" : \n       ($data.gainLoss >= 0 ? \"+\" : \"-\") + Math.abs($data.gainLoss).toFixed(2);",
                  "mock": "+16.28"
                },
                "width": 302,
                "height": 75,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 70,
                "color": {
                  "type": "JSExpression",
                  "value": "// FIA标准配色方案\nreturn $data.gainLoss > 0 ? \"#FF0000\" :\n       $data.gainLoss < 0 ? \"#00FF00\" :\n       \"#00FF00\";",
                  "mock": "#ffffff"
                },
                "padding": 0,
                "wrap": "nowrap",
                "left": 494,
                "top": 40,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_8_rhw0fg5",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "DELTA",
                "width": 167,
                "height": 35,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 559,
                "top": 132,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_9_kjsnnqn",
          "name": "Layer 3",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 505,
            "top": 105,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_10_qsbvtbe",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示整数RPM值（自动处理无效数据）\nreturn isNaN($data.rpm) ? \"--\" : Math.round($data.rpm);",
                  "mock": "2500"
                },
                "width": 258,
                "height": 77,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 72,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 510,
                "top": 257,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_11_m1jfniq",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "RPM",
                "width": 161,
                "height": 31,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 559,
                "top": 220,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_12_f4hb9vg",
          "name": "Layer 4",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": -26,
            "top": 210,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_13_xmgwqgk",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示整数圈数（自动处理异常值）\nreturn $data.completedLaps",
                  "mock": "6"
                },
                "width": 112,
                "height": 91,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 72,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 31,
                "top": 371,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_14_u79t90t",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "LAP",
                "width": 85,
                "height": 24,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 44.5,
                "top": 347,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_15_vub3ap9",
          "name": "Layer 5",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 124,
            "top": 207,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_16_2wh9iav",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示当前名次（自动处理无效值）\nreturn isNaN($data.position) ? \"--\" : $data.position;",
                  "mock": "4"
                },
                "width": 91,
                "height": 69,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 72,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 188,
                "top": 384,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_17_4jlwiy9",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "POS",
                "width": 103,
                "height": 24,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 182,
                "top": 346,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_18_4jqp7ek",
          "name": "Layer 6",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 606,
            "top": 236,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_19_fswworb",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示整数油温（自动处理无效值）\nreturn isNaN($data.waterTemperature) ? \"---\" : Math.round($data.waterTemperature);",
                  "mock": "93"
                },
                "width": 104,
                "height": 67,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 68,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 664,
                "top": 397,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_20_oqmu2l0",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "WATER",
                "width": 123,
                "height": 30,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 653,
                "top": 353,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_24_t6ltcrp",
          "name": "Layer 8",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 467,
            "top": 236,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_25_loqyzdp",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示带1位小数的燃油量（自动处理异常值）\nreturn isNaN(parseFloat($data.fuel))?\"--.-\":parseFloat($data.fuel).toFixed(1);",
                  "mock": "30.1"
                },
                "width": 138,
                "height": 67,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 68,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 504,
                "top": 397,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_26_uzxjuz5",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "FUEL",
                "width": 145,
                "height": 30,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 497,
                "top": 353,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_27_43i2n6a",
          "name": "Layer 9",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 18,
            "top": 106,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_28_d6hofni",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// ===== Run Once 初始化 =====\nif (typeof $scope.lastLap === 'undefined') {\n  $scope.lastLap = {\n    display: \"00:00.000\",\n    raw: 0,\n    valid: false\n  };\n}\n\n// ===== 主显示逻辑 =====\nfunction formatLap(ms) {\n  if (isNaN(parseFloat(ms))) {\n    $scope.lastLap.valid = false;\n    return $scope.lastLap.display;\n  }\n\n  var d = new Date(parseInt(ms));\n  $scope.lastLap.raw = ms;\n  $scope.lastLap.valid = true;\n  \n  return (\n    ('0' + d.getUTCMinutes()).slice(-2) + ':' +\n    ('0' + d.getUTCSeconds()).slice(-2) + '.' +\n    ('00' + d.getUTCMilliseconds()).slice(-3)\n  );\n}\n\nreturn formatLap($data.lastLapTime);",
                  "mock": "1:59.112"
                },
                "width": 278,
                "height": 56,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 54,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 24,
                "top": 255,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_29_nz00npm",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": "LAST LAP",
                "width": 173,
                "height": 36,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 24,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 72,
                "top": 219,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_31_mxpvcso",
          "name": "Layer 10",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 265,
            "top": 165,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100
          },
          "children": [
            {
              "id": "node_32_ljwe4ib",
              "name": "Text 1",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// Text元件的\"内容(content)\"属性FX：\nreturn $data.gear === 0 ? \"N\" : ($data.gear === -1 ? \"R\" : $data.gear);",
                  "mock": "N"
                },
                "width": 195,
                "height": 288,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 280,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 309,
                "top": 192,
                "fontFamily": "Fjalla One"
              }
            },
            {
              "id": "node_33_m0iku8u",
              "name": "Text 2",
              "componentName": "Text",
              "lifeCycles": {},
              "props": {
                "value": {
                  "type": "JSExpression",
                  "value": "// 显示整数车速（自动处理无效值）\nreturn isNaN($data.speed) ? \"---\" : Math.round($data.speed);",
                  "mock": "0"
                },
                "width": 183,
                "height": 73,
                "textAlign": "center",
                "verticalAlign": "center",
                "rotation": "",
                "visible": true,
                "borderColor": "rgba(255, 255, 255, 1)",
                "borderStyle": "solid",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 100,
                "fontSize": 54,
                "color": "#ffffff",
                "padding": 0,
                "wrap": "nowrap",
                "left": 315,
                "top": 132,
                "fontFamily": "Fjalla One"
              }
            }
          ]
        },
        {
          "id": "node_0_taeq4j6",
          "name": "Text 19",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "PIT LIMITER",
            "width": 299,
            "height": 56,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.isPitLimiterOn\n",
              "mock": true
            },
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 40,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 12,
            "top": 163,
            "backgroundColor": "#ff0008",
            "fontFamily": "Saira SemiCondensed",
            "fontWeight": 600
          }
        },
        {
          "id": "node_1_55859ab",
          "name": "Text 20",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "DRS ",
            "width": 108,
            "height": 56,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.isDrsEnabled",
              "mock": false
            },
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 40,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 12,
            "top": 163,
            "backgroundColor": "#03a600",
            "fontFamily": "Saira SemiCondensed",
            "fontWeight": 600
          }
        },
        {
          "id": "node_2_jdmgzxj",
          "name": "Text 21",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"BLACK\" :\n       $data.blueFlag ? \"BLUE\" :\n       $data.checkeredFlag ? \"CHECKERED\" :\n       $data.greenFlag ? \"GREEN\" :\n       $data.orangeFlag ? \"ORANGE\" :\n       $data.redFlag ? \"RED\" :\n       $data.whiteFlag ? \"WHITE\" :\n       $data.yellowFlag ? \"YELLOW\" :\n       \"\";\n",
              "mock": ""
            },
            "width": 286,
            "height": 55,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"BLACK\" :\n       $data.blueFlag ? \"BLUE\" :\n       $data.checkeredFlag ? \"CHECKERED\" :\n       $data.greenFlag ? \"GREEN\" :\n       $data.orangeFlag ? \"ORANGE\" :\n       $data.redFlag ? \"RED\" :\n       $data.whiteFlag ? \"WHITE\" :\n       $data.yellowFlag ? \"YELLOW\" :\n       \"\";\n",
              "mock": false
            },
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 40,
            "color": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"#FFFFFF\" :  \n       $data.blueFlag ? \"#FFFFFF\" :  \n       $data.checkeredFlag ? \"#000000\" : \n       $data.greenFlag ? \"#000000\" :\n       $data.orangeFlag ? \"#000000\" :  \n       $data.redFlag ? \"#FFFFFF\" :   \n       $data.whiteFlag ? \"#000000\" :  \n       $data.yellowFlag ? \"#000000\" : \n       \"#FFFFFF\";                  \n",
              "mock": "#ffffff"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 500,
            "top": 167,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"#000000\" : \n       $data.blueFlag ? \"#0000FF\" :   \n       $data.checkeredFlag ? \"#FFFFFF\" : \n       $data.greenFlag ? \"#00FF00\" :   \n       $data.orangeFlag ? \"#FFA500\" : \n       $data.redFlag ? \"#FF0000\" :     \n       $data.whiteFlag ? \"#DDDDDD\" :  \n       $data.yellowFlag ? \"#FFFF00\" :  \n       \"#3B3B3B\";                     \n",
              "mock": "#ffffff00"
            },
            "fontFamily": "Saira Expanded",
            "fontWeight": 600
          }
        }
      ],
      "roles": [
        "InGame",
        "Idel"
      ]
    }
  ],
  "assets": [
    {
      "id": "ff5eea07-49a6-4d56-85c6-f1fb72fcd893",
      "name": "企业微信截图_1739518095419",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 800,
        "height": 480
      }
    },
    {
      "id": "global-button-yellow",
      "name": "yellow button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-yellow-pressed",
      "name": "yellow button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green",
      "name": "green button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green-pressed",
      "name": "green button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-red",
      "name": "red button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-red-pressed",
      "name": "red button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    }
  ],
  "config": {
    "dash_name": "Formula_C",
    "device_size": [
      {
        "width": 800,
        "height": 480,
        "product_uuid": "0000000000000000",
        "product_name": "generic"
      }
    ],
    "category": {
      "formula": [
        "3a4b5c6d-7e8f-49a0-8b1c-2d3e4f5a6b7c"
      ]
    },
    "telemetry": [
      {
        "pageId": "node_0_97r69x6",
        "data": [
          "bestLapTime",
          "gainLoss",
          "rpm",
          "completedLaps",
          "position",
          "waterTemperature",
          "fuel",
          "lastLapTime",
          "gear",
          "speed",
          "isPitLimiterOn",
          "isDrsEnabled",
          "blackFlag",
          "blueFlag",
          "checkeredFlag",
          "greenFlag",
          "orangeFlag",
          "redFlag",
          "whiteFlag",
          "yellowFlag"
        ]
      }
    ],
    "width": 800,
    "height": 480
  }
}