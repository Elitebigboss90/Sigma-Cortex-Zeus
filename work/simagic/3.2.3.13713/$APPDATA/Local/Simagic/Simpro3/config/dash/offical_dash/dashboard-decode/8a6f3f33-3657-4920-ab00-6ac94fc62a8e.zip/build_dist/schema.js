window['__SCHEMA__'] = {
  "version": "1.0.0",
  "componentsMap": [
    {
      "componentName": "Rectangle"
    },
    {
      "componentName": "LinearGauge"
    },
    {
      "componentName": "Image"
    },
    {
      "componentName": "GaugeCanvas"
    },
    {
      "componentName": "Text"
    },
    {
      "componentName": "Layer"
    },
    {
      "componentName": "Page"
    },
    {
      "componentName": "GearIndicator"
    }
  ],
  "componentsTree": [
    {
      "id": "node_0_lvds2lb",
      "name": "Screen",
      "componentName": "Page",
      "lifeCycles": {},
      "props": {
        "width": 1280,
        "height": 720,
        "backgroundColor": "#edd2d200",
        "gridEnabled": false,
        "gridSize": 50,
        "gridColor": "#ffffff00",
        "top": -3
      },
      "children": [
        {
          "id": "node_5_2smyjhv",
          "name": "Rectangle 6",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 484,
            "height": 484,
            "rotation": "",
            "visible": false,
            "borderWidth": 0,
            "borderColor": "#302e2e00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 980,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#454545",
            "left": 398,
            "top": 136,
            "___syncing___": true,
            "___isLocked___": true
          }
        },
        {
          "id": "node_0_7az789i",
          "name": "油温",
          "componentName": "LinearGauge",
          "lifeCycles": {
            "componentDidMount.props.value": {
              "type": "JSExpression",
              "value": "return $data.oilTemperature=70"
            }
          },
          "props": {
            "width": 145,
            "height": 405,
            "backgroundColor": "#32323200",
            "rotation": "",
            "visible": true,
            "maximum": 200,
            "minimum": 0,
            "steps": 0,
            "value": {
              "type": "JSExpression",
              "value": "return $data.oilTemperature",
              "mock": 82
            },
            "gaugeColor": "#ffffff00",
            "borderColor": "#f63c0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 60,
            "gaugeAlignment": "flex-start",
            "gaugeOrientation": "vertical",
            "left": 951,
            "top": 176,
            "gaugeImage": "asset://ecdaa266-c148-4fbe-92d9-8f735fe31edc",
            "___isLocked___": false,
            "___syncing___": false,
            "shadowColor": "rgba(0, 0, 0, 0)",
            "shadowBlur": 0,
            "shadowSpread": 0,
            "shadowInset": false
          }
        },
        {
          "id": "node_6_dj6irro",
          "name": "水温",
          "componentName": "LinearGauge",
          "lifeCycles": {},
          "props": {
            "width": 146,
            "height": 405,
            "backgroundColor": "#32323200",
            "rotation": "",
            "visible": true,
            "maximum": 200,
            "minimum": 0,
            "steps": 0,
            "value": {
              "type": "JSExpression",
              "value": "return $data.waterTemperature",
              "mock": 50
            },
            "gaugeColor": "#f53b0d00",
            "borderColor": "#f63c0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 60,
            "gaugeAlignment": "flex-start",
            "gaugeOrientation": "vertical",
            "left": 186,
            "top": 175,
            "gaugeImage": "asset://81455a65-ed0d-454d-83ee-8f66f91117d1",
            "___isLocked___": false,
            "shadowColor": "rgba(0, 0, 0, 0)",
            "shadowBlur": 0,
            "shadowSpread": 0,
            "shadowInset": false
          }
        },
        {
          "id": "node_0_psjjd3x",
          "name": "Image 4",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 715,
            "height": 614,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 284,
            "top": 32,
            "image": "asset://3f147591-c7ae-4784-97b3-61676ab0a7c9",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_2_1mp5f5e",
          "name": "Image 6",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 700,
            "height": 700,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 290,
            "top": -14,
            "image": "asset://5d2a7e1b-3d67-4348-b64f-f5b1446236ec",
            "___isLocked___": true
          }
        },
        {
          "id": "node_6_yh7m0qc",
          "name": "Image 10",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 960,
            "height": 960,
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 162,
            "top": -103,
            "image": "asset://21f9f65b-c726-4400-8150-b871fe24062b",
            "___isLocked___": true
          }
        },
        {
          "id": "node_3_6l7shzh",
          "name": "Image 7",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 704,
            "height": 704,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 290,
            "top": -14,
            "image": "asset://cb166458-dc13-4d16-8670-70657c1181a8",
            "___isLocked___": true
          }
        },
        {
          "id": "node_7_z3yr5bj",
          "name": "RPM",
          "componentName": "GaugeCanvas",
          "lifeCycles": {},
          "props": {
            "width": 775,
            "height": 720,
            "backgroundColor": "rgba(50,50,50,0)",
            "rotation": 0,
            "visible": true,
            "value": {
              "type": "JSExpression",
              "value": "return $data.rpm;",
              "mock": 12000
            },
            "minimum": 0,
            "maximum": 12000,
            "startAngle": 135,
            "sweepAngle": 270,
            "dialStrokeColor": "#ffffff00",
            "dialBackgroundColor": "#00000000",
            "innerRadius": 25,
            "outerRadius": 30,
            "innerStrokeThickness": 6,
            "outerStrokeThickness": 9,
            "showDialGlassEffect": false,
            "majorTickColor": "#ffffff",
            "majorTickRadius": 197,
            "majorTickWidth": 15,
            "majorTickHeight": 6,
            "valuePerMajorDivision": 1000,
            "minorDivisionsCount": 3,
            "minorTickColor": "#ffffff",
            "minorTickRadius": 100,
            "pointerWidth": 14,
            "pointerLength": 345,
            "pointerImage": "asset://fa1bbeac-2c49-4d98-9c98-ead1b0a3c4b1",
            "backgroundImage": "",
            "gaugeTickLabelFontSize": 50,
            "gaugeTickLabelFontFamily": "Arial",
            "gaugeTickLabelColor": "#ffffff",
            "gaugeTickLabelOffset": 50,
            "gaugeTickLabelRotation": "horizontal",
            "gaugeTickLabelVisible": false,
            "gaugeCenterLabelText": "N",
            "gaugeCenterLabelFontSize": 40,
            "gaugeCenterLabelFontWeight": "bold",
            "gaugeCenterLabelColor": "#00000000",
            "gaugeCenterLabelOffsetY": 85,
            "gaugeCenterLabelVisible": false,
            "borderColor": "#f63c0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 1,
            "opacity": 100,
            "left": 253,
            "top": 18,
            "___syncing___": true,
            "___isLocked___": true,
            "shadowColor": "rgba(0, 0, 0, 0)",
            "shadowBlur": 0,
            "shadowSpread": 0,
            "shadowInset": false,
            "pointerSmoothingEnabled": true,
            "pointerSmoothingTime": 120,
            "pointerTrailEnabled": true,
            "pointerTrailMode": "comet",
            "pointerTrailColor": "#ff3b30",
            "pointerTrailDuration": 280,
            "pointerTrailOpacity": 80
          }
        },
        {
          "id": "node_0_xyhgtd5",
          "name": "Rectangle 1",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 440,
            "height": 440,
            "rotation": "",
            "visible": true,
            "borderWidth": 10,
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 396,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 423,
            "top": 157,
            "___syncing___": true,
            "___isLocked___": true
          }
        },
        {
          "id": "node_1_g89imsj",
          "name": "Rectangle 2",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 1274,
            "height": 105,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 0,
            "top": 653,
            "___isLocked___": true
          }
        },
        {
          "id": "node_2_om5qfck",
          "name": "Rectangle 3",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 105,
            "height": 171,
            "rotation": -38,
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 731,
            "top": 543,
            "___isLocked___": true
          }
        },
        {
          "id": "node_3_iv08vmo",
          "name": "Rectangle 4",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 105,
            "height": 171,
            "rotation": 39,
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 454,
            "top": 535,
            "___isLocked___": true
          }
        },
        {
          "id": "node_4_ppgkdse",
          "name": "Rectangle 5",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 288,
            "height": 180,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 498,
            "top": 558,
            "___isLocked___": true
          }
        },
        {
          "id": "node_8_n3cobfb",
          "name": "Image 1",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 190,
            "height": 54,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 548,
            "top": 151,
            "image": "asset://ef64ab7d-d2e0-412e-be1a-7c33a03ead59",
            "___syncing___": true,
            "___isLocked___": true
          }
        },
        {
          "id": "node_10_o5pd8jg",
          "name": "×1000rpm",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "×1000rpm",
            "width": 150,
            "height": 40,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 50,
            "fontSize": 26,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 0,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 567,
            "top": 166,
            "backgroundColor": "#00000000",
            "fontFamily": "Archivo",
            "fontStyle": "normal",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_11_spu4af1",
          "name": "Image 3",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 374,
            "height": 286,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 457,
            "top": 234,
            "image": "asset://420e8f28-2326-4039-b281-c6f744829b4a",
            "___syncing___": true,
            "___isLocked___": true
          }
        },
        {
          "id": "node_13_exawc9l",
          "name": "Rectangle 8",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 79,
            "height": 43,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 602,
            "top": 222,
            "___isLocked___": true
          }
        },
        {
          "id": "node_12_bmpidua",
          "name": "km/h",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "km/h",
            "width": 151,
            "height": 40,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 80,
            "fontSize": 30,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 0,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 566,
            "top": 227,
            "backgroundColor": "#00000000",
            "fontFamily": "Archivo",
            "fontStyle": "normal",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_14_5ttrciw",
          "name": "speed",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数车速（自动处理无效值）\nreturn isNaN($data.speed) ? \"---\" : Math.round($data.speed);",
              "mock": "156"
            },
            "width": 374,
            "height": 224,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 185,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 0,
            "textShadowColor": "#79797900",
            "textShadowDirection": 135,
            "left": 455,
            "top": 265,
            "fontFamily": "Figtree",
            "letterSpacing": 0,
            "fontWeight": 600,
            "___isLocked___": true,
            "shadowColor": "rgba(0, 0, 0, 0)",
            "shadowBlur": 0,
            "shadowSpread": 0,
            "shadowInset": false,
            "steadyNumbers": true
          }
        },
        {
          "id": "node_1_yxie9nt",
          "name": "Image 5",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 644,
            "height": 643,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 318,
            "top": 5,
            "image": "asset://bcb459ee-fe2b-4a8e-b5c3-245c90922632",
            "___isLocked___": true
          }
        },
        {
          "id": "node_4_qknpu32",
          "name": "Image 8",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 670,
            "height": 670,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 150,
            "blinkEnabled": {
              "type": "JSExpression",
              "value": "return $data.rpmPercentage >=95",
              "mock": false
            },
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 307,
            "top": 1,
            "image": "asset://d9e99e55-b97e-4bde-b6ee-2f1f40e9c350",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_5_gum9jgx",
          "name": "Image 9",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 1185,
            "height": 160,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 51,
            "top": 561,
            "image": "asset://fd47b1ef-32b9-450d-9f94-4e34dda8ac70",
            "___isLocked___": true,
            "___syncing___": false
          }
        },
        {
          "id": "node_10_b8vtfrb",
          "name": "Image 13",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 73,
            "height": 73,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 917,
            "top": 43,
            "image": "asset://26e4696d-e111-4ac5-b7b1-df4586b85f5d",
            "___isLocked___": true
          }
        },
        {
          "id": "node_11_7eit0x4",
          "name": "Image 14",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 60,
            "height": 60,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 302,
            "top": 46,
            "image": "asset://a02eb5ac-4c8b-486a-8a19-2b7b05c03f4e",
            "___isLocked___": true,
            "backgroundColor": "#ffffff00",
            "___syncing___": true
          }
        },
        {
          "id": "node_12_fvl46jv",
          "name": "Text 5",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "C",
            "width": 62,
            "height": 60,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 47,
            "color": "#d7d7d7",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 940,
            "top": 588,
            "fontFamily": "Figtree",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_13_ujt2kj5",
          "name": "Text 6",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "H",
            "width": 62,
            "height": 60,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 47,
            "color": "#d7d7d7",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 940,
            "top": 116,
            "fontFamily": "Figtree",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_14_d9wat2x",
          "name": "Text 7",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "H",
            "width": 62,
            "height": 60,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 47,
            "color": "#d7d7d7",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 281,
            "top": 106,
            "fontFamily": "Figtree",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_15_3tfego6",
          "name": "Text 8",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "C",
            "width": 62,
            "height": 60,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 47,
            "color": "#d7d7d7",
            "padding": 0,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 277,
            "top": 588,
            "fontFamily": "Figtree",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_37_o8d3r79",
          "name": "油箱",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 0,
            "top": 0,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "___isLocked___": true
          },
          "children": [
            {
              "id": "node_16_hlijsk4",
              "name": "油1",
              "componentName": "Image",
              "lifeCycles": {
                "componentDidMount.props.blinkEnabled": {
                  "type": "JSExpression",
                  "value": "return $data.fuelPercent"
                }
              },
              "props": {
                "width": 30,
                "height": 30,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 0;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 500,
                "blinkEnabled": {
                  "type": "JSExpression",
                  "value": "return $data.fuelPercent <= 5;",
                  "mock": false
                },
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 86,
                "top": 8,
                "image": "asset://6bda761c-b3eb-4764-8bae-04ec9f3e3fcd",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_2_x5tu6qu",
              "name": "油2",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 56,
                "height": 56,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 14.1;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 86,
                "top": 7,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://3cc82a3f-ca93-4faf-aad2-ac41d3fbc01e"
              }
            },
            {
              "id": "node_18_xb1v1p3",
              "name": "油3",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 81,
                "height": 81,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 28.2;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 89,
                "top": -2,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://b2a62081-9a17-4a30-a8a0-8b2d2bc26b06"
              }
            },
            {
              "id": "node_19_8y9up5t",
              "name": "油4",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 84,
                "height": 84,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 42.3;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 118,
                "top": -4,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://578ce8ea-8124-4c83-9ab0-c05fae2510ea"
              }
            },
            {
              "id": "node_20_ndvlaj3",
              "name": "油5",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 81,
                "height": 81,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 56.4;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 148,
                "top": -2,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://0f56b69d-af77-4117-b84f-bd7fd1b7b37b"
              }
            },
            {
              "id": "node_21_upv04n4",
              "name": "油6",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 82,
                "height": 82,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent > 70.5;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 174,
                "top": -3,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://11a17903-b746-4bca-8012-6fd2333ad0fd"
              }
            },
            {
              "id": "node_22_arj90rb",
              "name": "油7",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 85,
                "height": 85,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "// 燃油大于14.1开启，否则关闭\n{\n  return $data.fuelPercent >84.6;\n}\n\n// 使用方式\ncheckFuelState($data.fuelPercent);",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 0,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 203,
                "top": -4,
                "___isLocked___": true,
                "___syncing___": true,
                "image": "asset://668ca2fe-389e-488c-87d9-a8e6779426e7"
              }
            },
            {
              "id": "node_5_rgqjgr5",
              "name": "油量",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 337,
                "height": 200,
                "rotation": "",
                "visible": true,
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 80,
                "objectFit": "contain",
                "left": 0,
                "top": -54,
                "image": "asset://25097385-ca5b-4875-a627-794745e8d3f4",
                "___isLocked___": true
              }
            }
          ]
        },
        {
          "id": "node_38_u505jkd",
          "name": "电池",
          "componentName": "Layer",
          "lifeCycles": {},
          "props": {
            "width": 200,
            "height": 200,
            "left": 0,
            "top": 0,
            "rotation": "",
            "visible": true,
            "___supportRefreshInterval___": true,
            "borderStyle": "none",
            "borderRadius": 0,
            "borderWidth": 0,
            "borderColor": "rgb(0,0,0,1)",
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "___isLocked___": true
          },
          "children": [
            {
              "id": "node_3_vybw2wt",
              "name": "电1",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 30,
                "height": 30,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 0;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 500,
                "blinkEnabled": {
                  "type": "JSExpression",
                  "value": "return $data.ersPercent<=5",
                  "mock": false
                },
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1166,
                "top": 8,
                "image": "asset://dfcd5a09-ce93-49e8-aa54-597cc1494c87",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_31_yjj9qof",
              "name": "电2",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 56,
                "height": 56,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 14.1;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1140,
                "top": 7,
                "image": "asset://03011666-f6c3-4052-86ad-ba69c823e274",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_32_cliryek",
              "name": "电3",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 82,
                "height": 82,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 28.2;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1111,
                "top": -3,
                "image": "asset://8ab77359-8e4d-4db2-b403-202c8998dae2",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_33_humbszr",
              "name": "电4",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 84,
                "height": 84,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 42.3;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1080,
                "top": -4,
                "image": "asset://440f9356-fa1d-4a96-abf1-1b3f64a266de",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_34_1hq4f2h",
              "name": "电5",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 81,
                "height": 81,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 72.4;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1054,
                "top": -2,
                "image": "asset://bdb346a4-97fa-446f-aa41-a6bad185a593",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_35_6bzg22w",
              "name": "电6",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 82,
                "height": 82,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 70.5;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 1025,
                "top": -3,
                "image": "asset://2d78bf36-e7ff-4d2c-b24f-33f1736fd045",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_36_cwmfmqh",
              "name": "电7",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 85,
                "height": 85,
                "rotation": "",
                "visible": {
                  "type": "JSExpression",
                  "value": "{\n  return $data.ersPercent > 84.6;\n}\n",
                  "mock": true
                },
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 60,
                "objectFit": "contain",
                "left": 995,
                "top": -4,
                "image": "asset://af9e649f-38c7-4fc5-82a1-fcf1b7445861",
                "___isLocked___": true,
                "___syncing___": true
              }
            },
            {
              "id": "node_9_lm33pig",
              "name": "电池",
              "componentName": "Image",
              "lifeCycles": {},
              "props": {
                "width": 337,
                "height": 200,
                "rotation": "",
                "visible": true,
                "borderColor": "#f53b0d00",
                "borderStyle": "none",
                "___supportRefreshInterval___": true,
                "borderRadius": 0,
                "borderWidth": 2,
                "blinkDelay": 0,
                "blinkEnabled": false,
                "blurRadius": 0,
                "opacity": 80,
                "objectFit": "contain",
                "left": 945,
                "top": -54,
                "image": "asset://d61364a0-6068-4056-9262-ce7cfce19e15",
                "___isLocked___": true
              }
            }
          ]
        },
        {
          "id": "node_7_sb9w2nm",
          "name": "TC sign",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 113,
            "height": 113,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return parseFloat($data.tcLevel) !== 0",
              "mock": true
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 1142,
            "top": 345,
            "image": "asset://81ff6513-d167-4053-9c7b-aaa9adeb0a39",
            "___isLocked___": false,
            "___syncing___": true
          }
        },
        {
          "id": "node_8_ioshy8g",
          "name": "TC",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let val = $data.tcLevel;\n\n// 游戏关闭或无效值 → \"OFF\"，否则四舍五入显示\nreturn (isNaN(val) || val === null|| val === 0) ? \"OFF\" : Math.round(val);",
              "mock": "2"
            },
            "width": 120,
            "height": 56,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return parseFloat($data.tcLevel) !== 0",
              "mock": true
            },
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 45,
            "color": "#e60013",
            "padding": 8,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "#79797900",
            "textShadowDirection": 135,
            "left": 1139,
            "top": 440,
            "fontFamily": "Zen Dots",
            "fontWeight": "normal",
            "___isLocked___": true
          }
        },
        {
          "id": "node_9_vipdryt",
          "name": "tc OFF",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 115,
            "height": 115,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "let level = Number($data.tcLevel);\nreturn level === 0;",
              "mock": false
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 1141,
            "top": 230,
            "image": "asset://f89b7458-ad01-46fb-aa0a-28635e004ceb",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_0_io2hiok",
          "name": "ABS sign",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 113,
            "height": 113,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 30,
            "top": 347,
            "image": "asset://21b55388-8756-4820-84ab-d83230be3a7c",
            "___isLocked___": true
          }
        },
        {
          "id": "node_1_x7e7ain",
          "name": "ABS",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let val = $data.absLevel;\n\n// 游戏关闭或无效值 → \"OFF\"，否则四舍五入显示\nreturn (isNaN(val) || val === null|| val === 0) ? \"OFF\" : Math.round(val);",
              "mock": "2"
            },
            "width": 145,
            "height": 56,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 45,
            "color": "#ffffff",
            "padding": 8,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "#79797900",
            "textShadowDirection": 135,
            "left": 11,
            "top": 440,
            "fontFamily": "Zen Dots",
            "fontWeight": "normal",
            "___isLocked___": true,
            "___syncing___": false
          }
        },
        {
          "id": "node_0_5sbsgnw",
          "name": "Image 35",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 106,
            "height": 106,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.gear < 1",
              "mock": true
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 30,
            "top": 241,
            "image": "asset://35e9c0ae-2019-42c9-a71e-fdff29ac9818",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_1_7duersy",
          "name": "Image 36",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 86,
            "height": 86,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.gear < 0",
              "mock": false
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 40,
            "top": 249,
            "image": "asset://cb4f3182-02c3-4995-96e8-5226779e44d4",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_2_yhi1s51",
          "name": "Image 31",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 106,
            "height": 106,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.gear>=1",
              "mock": false
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 30,
            "top": 240,
            "image": "asset://47432fbc-b85a-4c71-9bd5-b92d1c5add3d",
            "___isLocked___": true
          }
        },
        {
          "id": "node_3_3947zft",
          "name": "roadT",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数温度值 + ℃单位\nreturn Math.round($data.roadTemperature) ;",
              "mock": "21"
            },
            "width": 96,
            "height": 67,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 51,
            "color": "#bababa",
            "padding": 8,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 1106,
            "top": 653,
            "fontFamily": "Public Sans",
            "___isLocked___": true
          }
        },
        {
          "id": "node_5_bu4q1u9",
          "name": "℃",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 47,
            "height": 47,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 1202,
            "top": 663,
            "image": "asset://d3ff670e-0799-4dc5-9988-1dffabb71ecc",
            "___isLocked___": true
          }
        },
        {
          "id": "node_6_pwgo1kd",
          "name": "秒表",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 45,
            "height": 42,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 275,
            "top": 663,
            "image": "asset://039f87e4-f330-45d4-8142-4c0e2d30a679",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_8_u9yr2os",
          "name": "last lap",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// ===== Run Once 初始化 =====\nif (typeof $scope.lastLap === 'undefined') {\n  $scope.lastLap = {\n    display: \"00:00.000\",\n    raw: 0,\n    valid: false\n  };\n}\n\n// ===== 主显示逻辑 =====\nfunction formatLap(s) {\n  if (isNaN(parseFloat(s))) {\n    $scope.lastLap.valid = false;\n    return $scope.lastLap.display;\n  }\n\n  var d = new Date(parseInt(s));\n  $scope.lastLap.raw = s;\n  $scope.lastLap.valid = true;\n  \n  return (\n    ('0' + d.getUTCMinutes()).slice(-2) + ':' +\n    ('0' + d.getUTCSeconds()).slice(-2) + '.' +\n    ('0' + d.getUTCMilliseconds()).slice(-3)\n  );\n}\n\nreturn formatLap($data.lastLapTime);",
              "mock": "00.00.000"
            },
            "width": 266,
            "height": 48,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 42,
            "color": "#bababa",
            "padding": 8,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 7,
            "top": 663,
            "fontFamily": "Public Sans",
            "___isLocked___": true,
            "steadyNumbers": false
          }
        },
        {
          "id": "node_0_gmzy1ft",
          "name": "Image 37",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 106,
            "height": 106,
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.turnIndicatorLeft",
              "mock": false
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 150,
            "blinkEnabled": {
              "type": "JSExpression",
              "value": "return $data.turnIndicatorLeft",
              "mock": true
            },
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 30,
            "top": 102,
            "image": "asset://d669a04d-954f-43b1-8355-d0ec0e0a6831"
          }
        },
        {
          "id": "node_1_p9a9ags",
          "name": "Image 38",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 106,
            "height": 106,
            "rotation": 180,
            "visible": {
              "type": "JSExpression",
              "value": "return $data.turnIndicatorRight",
              "mock": false
            },
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 150,
            "blinkEnabled": {
              "type": "JSExpression",
              "value": "return $data.turnIndicatorRight",
              "mock": true
            },
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 1148,
            "top": 102,
            "image": "asset://d669a04d-954f-43b1-8355-d0ec0e0a6831"
          }
        },
        {
          "id": "node_2_bflwbje",
          "name": "Image 39",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 118,
            "height": 118,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 25,
            "top": 500,
            "image": "asset://346e834a-b91d-4948-a626-c5c2afc8f3f4"
          }
        },
        {
          "id": "node_3_6or5fv1",
          "name": "Image 40",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 97,
            "height": 97,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 1122,
            "top": 504,
            "image": "asset://843dbec3-b0f1-46db-82ae-d98c2c536644"
          }
        },
        {
          "id": "node_0_b0x3h7d",
          "name": "Text 13",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "$scope.bestTime = \"00:00.000\";\n$scope.lastValid = 0;\nfunction format(ms) {\n  if (!Number.isFinite(ms)) return $scope.bestTime;\n  \n  const d = new Date(ms);\n  $scope.lastValid = ms;\n  return `${d.getUTCMinutes().toString().padStart(2,'0')}:` +\n         `${d.getUTCSeconds().toString().padStart(2,'0')}.` +\n         `${d.getUTCMilliseconds().toString().padStart(3,'0')}`;\n}\n\nreturn $scope.bestTime = format($data.bestLapTime);",
              "mock": "00.00.000"
            },
            "width": 249,
            "height": 48,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "#ffffff00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 42,
            "color": "#cd1aff",
            "padding": 8,
            "wrap": "nowrap",
            "textShadowDepth": 0,
            "textShadowBlur": 2,
            "textShadowColor": "rgba(121, 121, 121, 0.9)",
            "textShadowDirection": 135,
            "left": 339,
            "top": 663,
            "fontFamily": "Public Sans",
            "___isLocked___": true,
            "steadyNumbers": false
          }
        },
        {
          "id": "node_1_cpueyp7",
          "name": "Image 41",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 45,
            "height": 42,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d00",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 590,
            "top": 662,
            "image": "asset://87999dd0-7f45-4b10-b8b3-888422366b0c",
            "___isLocked___": true,
            "___syncing___": true
          }
        },
        {
          "id": "node_0_h36x2a6",
          "name": "GearIndicator 1",
          "componentName": "GearIndicator",
          "lifeCycles": {},
          "props": {
            "width": 277,
            "height": 145,
            "rotation": "",
            "visible": true,
            "value": {
              "type": "JSExpression",
              "value": "// Text元件的\"内容(content)\"属性FX：\nreturn $data.gear",
              "mock": 0
            },
            "neighborCount": 1,
            "slotSpacing": 94,
            "fontFamily": "Figtree",
            "fontSize": 160,
            "fontStyle": "normal",
            "fontWeight": "bold",
            "currentColor": "#FFFFFF",
            "neighborColor": "#8A8A8A",
            "neighborMinOpacity": 35,
            "neighborScale": 70,
            "reverseLabel": "R",
            "neutralLabel": "N",
            "edgeFadeWidth": 40,
            "rollEnabled": true,
            "rollTime": 120,
            "borderColor": "rgba(255, 255, 255, 0)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "left": 497,
            "top": 507,
            "shadowColor": "rgba(0, 0, 0, 0)",
            "shadowBlur": 0,
            "shadowSpread": 0,
            "shadowInset": false
          }
        }
      ],
      "roles": [
        "InGame",
        "Idel"
      ]
    }
  ],
  "assets": [
    {
      "id": "940f1d0d-f3de-45b0-8530-cd25c3ff4938",
      "name": "图层 10",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 95,
        "height": 33
      }
    },
    {
      "id": "3a6880fb-411e-433e-92a3-29653127c187",
      "name": "图层 9",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 85,
        "height": 75
      }
    },
    {
      "id": "51374e1f-52c1-470a-8753-8bdb3203ead7",
      "name": "图层 8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 67,
        "height": 65
      }
    },
    {
      "id": "5f563b1b-7920-4776-ba9f-963097a97912",
      "name": "图层 7",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 77,
        "height": 61
      }
    },
    {
      "id": "15fe9cb1-fc33-43ad-8970-a9dc2096ecb3",
      "name": "图层 6",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 77,
        "height": 61
      }
    },
    {
      "id": "8e2605c5-6040-4987-94c2-22eb57c4ca4a",
      "name": "图层 5",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 81,
        "height": 54
      }
    },
    {
      "id": "f4b1e4cc-12f9-4428-a08c-90231d422757",
      "name": "图层 4",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 84,
        "height": 76
      }
    },
    {
      "id": "bcb9ea7f-fe1e-42a2-9a1d-88c9b05cb866",
      "name": "图层 3",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 95,
        "height": 59
      }
    },
    {
      "id": "ed0751b7-19bb-4c1f-a90a-bce575f05ba1",
      "name": "图层 2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 110,
        "height": 55
      }
    },
    {
      "id": "cb4f3182-02c3-4995-96e8-5226779e44d4",
      "name": "倒退",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 43,
        "height": 90
      }
    },
    {
      "id": "35e9c0ae-2019-42c9-a71e-fdff29ac9818",
      "name": "车辆标志",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 108,
        "height": 28
      }
    },
    {
      "id": "f89b7458-ad01-46fb-aa0a-28635e004ceb",
      "name": "TCOFF",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 74,
        "height": 106
      }
    },
    {
      "id": "81ff6513-d167-4053-9c7b-aaa9adeb0a39",
      "name": "TC",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 108,
        "height": 62
      }
    },
    {
      "id": "81455a65-ed0d-454d-83ee-8f66f91117d1",
      "name": "shui 2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 364,
        "height": 1024
      }
    },
    {
      "id": "1cf20c0a-ce38-411d-a27b-64744188bef1",
      "name": "you",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 474,
        "height": 136
      }
    },
    {
      "id": "ecdaa266-c148-4fbe-92d9-8f735fe31edc",
      "name": "1212",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 364,
        "height": 1024
      }
    },
    {
      "id": "3dcafe3d-d2a5-4388-94e4-ad0077808035",
      "name": "图层 2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 130,
        "height": 480
      }
    },
    {
      "id": "420e8f28-2326-4039-b281-c6f744829b4a",
      "name": "直线 2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 506,
        "height": 370
      }
    },
    {
      "id": "a0fcb8ce-d6fe-42c0-a3fd-1c1172539a61",
      "name": "直线 2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 506,
        "height": 387
      }
    },
    {
      "id": "563e5539-b26e-417f-8504-f3c908243809",
      "name": "22",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 496,
        "height": 56
      }
    },
    {
      "id": "ef64ab7d-d2e0-412e-be1a-7c33a03ead59",
      "name": "遮罩6",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 244,
        "height": 58
      }
    },
    {
      "id": "fa1bbeac-2c49-4d98-9c98-ead1b0a3c4b1",
      "name": "矩形 1",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 67,
        "height": 335
      }
    },
    {
      "id": "global-button-yellow",
      "name": "yellow button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-yellow-pressed",
      "name": "yellow button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green",
      "name": "green button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green-pressed",
      "name": "green button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-red",
      "name": "red button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-red-pressed",
      "name": "red button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "3f147591-c7ae-4784-97b3-61676ab0a7c9",
      "name": "9@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 1792,
        "height": 1591
      }
    },
    {
      "id": "bcb459ee-fe2b-4a8e-b5c3-245c90922632",
      "name": "7@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 1676,
        "height": 1407
      }
    },
    {
      "id": "5d2a7e1b-3d67-4348-b64f-f5b1446236ec",
      "name": "8@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 1793,
        "height": 1587
      }
    },
    {
      "id": "cb166458-dc13-4d16-8670-70657c1181a8",
      "name": "10@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 1824,
        "height": 1618
      }
    },
    {
      "id": "d9e99e55-b97e-4bde-b6ee-2f1f40e9c350",
      "name": "6@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 1722,
        "height": 1643
      }
    },
    {
      "id": "fd47b1ef-32b9-450d-9f94-4e34dda8ac70",
      "name": "11@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 3060,
        "height": 60
      }
    },
    {
      "id": "c7a228be-5754-4bf2-8658-d0ea6ea21599",
      "name": "5@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 2430,
        "height": 1232
      }
    },
    {
      "id": "25097385-ca5b-4875-a627-794745e8d3f4",
      "name": "1@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 800,
        "height": 178
      }
    },
    {
      "id": "d61364a0-6068-4056-9262-ce7cfce19e15",
      "name": "2@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 798,
        "height": 178
      }
    },
    {
      "id": "3d38b380-0c08-4ddf-9715-784acd507b99",
      "name": "4@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 210,
        "height": 158
      }
    },
    {
      "id": "4d4c0373-121a-47dd-9814-3ab09d6af210",
      "name": "3@4x-8",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 155,
        "height": 141
      }
    },
    {
      "id": "a02eb5ac-4c8b-486a-8a19-2b7b05c03f4e",
      "name": "图1",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 155,
        "height": 141
      }
    },
    {
      "id": "efb7b904-1619-462c-968a-765013194370",
      "name": "图2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 210,
        "height": 158
      }
    },
    {
      "id": "6bda761c-b3eb-4764-8bae-04ec9f3e3fcd",
      "name": "油1",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 63,
        "height": 59
      }
    },
    {
      "id": "3cc82a3f-ca93-4faf-aad2-ac41d3fbc01e",
      "name": "油2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 127,
        "height": 120
      }
    },
    {
      "id": "b2a62081-9a17-4a30-a8a0-8b2d2bc26b06",
      "name": "油3",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 186,
        "height": 136
      }
    },
    {
      "id": "578ce8ea-8124-4c83-9ab0-c05fae2510ea",
      "name": "油4",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 191,
        "height": 136
      }
    },
    {
      "id": "0f56b69d-af77-4117-b84f-bd7fd1b7b37b",
      "name": "油5",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 183,
        "height": 136
      }
    },
    {
      "id": "11a17903-b746-4bca-8012-6fd2333ad0fd",
      "name": "油6",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 187,
        "height": 136
      }
    },
    {
      "id": "668ca2fe-389e-488c-87d9-a8e6779426e7",
      "name": "油7",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 192,
        "height": 136
      }
    },
    {
      "id": "dfcd5a09-ce93-49e8-aa54-597cc1494c87",
      "name": "电1",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 63,
        "height": 59
      }
    },
    {
      "id": "03011666-f6c3-4052-86ad-ba69c823e274",
      "name": "电2",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 127,
        "height": 120
      }
    },
    {
      "id": "8ab77359-8e4d-4db2-b403-202c8998dae2",
      "name": "电3",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 186,
        "height": 136
      }
    },
    {
      "id": "440f9356-fa1d-4a96-abf1-1b3f64a266de",
      "name": "电4",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 191,
        "height": 136
      }
    },
    {
      "id": "bdb346a4-97fa-446f-aa41-a6bad185a593",
      "name": "电5",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 183,
        "height": 136
      }
    },
    {
      "id": "2d78bf36-e7ff-4d2c-b24f-33f1736fd045",
      "name": "电6",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 187,
        "height": 136
      }
    },
    {
      "id": "af9e649f-38c7-4fc5-82a1-fcf1b7445861",
      "name": "电7",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 192,
        "height": 136
      }
    },
    {
      "id": "21b55388-8756-4820-84ab-d83230be3a7c",
      "name": "ABS",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 110,
        "height": 62
      }
    },
    {
      "id": "47432fbc-b85a-4c71-9bd5-b92d1c5add3d",
      "name": "3213",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 109,
        "height": 89
      }
    },
    {
      "id": "d3ff670e-0799-4dc5-9988-1dffabb71ecc",
      "name": "摄氏度",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 56,
        "height": 47
      }
    },
    {
      "id": "039f87e4-f330-45d4-8142-4c0e2d30a679",
      "name": "秒表",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 458,
        "height": 512
      }
    },
    {
      "id": "87999dd0-7f45-4b10-b8b3-888422366b0c",
      "name": "pbL",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 458,
        "height": 512
      }
    },
    {
      "id": "21f9f65b-c726-4400-8150-b871fe24062b",
      "name": "mmexport1782454884020",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 2446,
        "height": 1238
      }
    },
    {
      "id": "26e4696d-e111-4ac5-b7b1-df4586b85f5d",
      "name": "mmexport1782454877555",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 240,
        "height": 159
      }
    },
    {
      "id": "d9aaa6f2-71d2-490d-a941-b94aeda39447",
      "name": "mmexport1782454869574",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 800,
        "height": 179
      }
    },
    {
      "id": "933880ce-1161-4e25-9d34-4321722eb94d",
      "name": "mmexport1782454873786",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 798,
        "height": 179
      }
    },
    {
      "id": "d669a04d-954f-43b1-8355-d0ec0e0a6831",
      "name": "←",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 94,
        "height": 99
      }
    },
    {
      "id": "346e834a-b91d-4948-a626-c5c2afc8f3f4",
      "name": "图标",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 146,
        "height": 146
      }
    },
    {
      "id": "843dbec3-b0f1-46db-82ae-d98c2c536644",
      "name": "LC",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 108,
        "height": 66
      }
    },
    {
      "id": "ce7d759b-cf43-4cbc-9090-ef54b40c0937",
      "name": "底部、",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 918,
        "height": 93
      }
    }
  ],
  "config": {
    "dash_name": "Valkyrie 假车",
    "device_size": [
      {
        "width": 1280,
        "height": 720,
        "product_uuid": "0000000000000000",
        "product_name": "generic"
      }
    ],
    "width": 1280,
    "height": 720,
    "category": {},
    "telemetry": [
      {
        "pageId": "node_0_lvds2lb",
        "data": [
          "oilTemperature",
          "waterTemperature",
          "rpm",
          "speed",
          "rpmPercentage",
          "fuelPercent",
          "ersPercent",
          "tcLevel",
          "absLevel",
          "gear",
          "roadTemperature",
          "lastLapTime",
          "turnIndicatorLeft",
          "turnIndicatorRight",
          "bestLapTime"
        ]
      }
    ]
  }
}