// Auto-generated fonts.js
(function() {
  const css = `@font-face {
  font-family: 'Goldman';
  src: url('./assets/fonts/Goldman-Regular.woff2') format('woff2');
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}`;

  if (typeof document !== 'undefined') {
    const style = document.createElement('style');
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
  }
})();