window['__SCHEMA__'] = {
  "version": "1.0.0",
  "componentsMap": [
    {
      "componentName": "Image"
    },
    {
      "componentName": "Text"
    },
    {
      "componentName": "Rectangle"
    },
    {
      "componentName": "Page"
    }
  ],
  "componentsTree": [
    {
      "id": "node_0_pt1ppkg",
      "name": "Screen",
      "componentName": "Page",
      "lifeCycles": {},
      "props": {
        "width": 800,
        "height": 480,
        "backgroundColor": "#000000",
        "gridEnabled": false,
        "gridSize": 50,
        "gridColor": "rgba(255, 255, 255, 0.3)"
      },
      "children": [
        {
          "id": "node_0_cpar1tl",
          "name": "BG",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 800,
            "height": 480,
            "rotation": "",
            "visible": true,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 2,
            "top": 0,
            "image": "asset://e4a5eb0e-34c4-4f2a-9c2d-d27b60173f51"
          }
        },
        {
          "id": "node_6_tdnrw1g",
          "name": "Text 1",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数（自动处理无效值）\nreturn isNaN($data.engineMap) ? \"---\" : Math.round($data.engineMap);",
              "mock": "3"
            },
            "width": 68,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 38,
            "color": "#3964ff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 224,
            "top": 47,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_7_2f8vyrr",
          "name": "Text 2",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let val = $data.tcLevel;\n// 游戏关闭或无效值 → \"OFF\"，否则四舍五入显示\nreturn (isNaN(val) || val === null|| val === 0) ? \"OFF\" : Math.round(val);\n",
              "mock": "2"
            },
            "width": 83,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 38,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 320,
            "top": 47,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_8_jot0via",
          "name": "Text 3",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let val = $data.absLevel;\n// 游戏关闭或无效值 → \"OFF\"，否则四舍五入显示\nreturn (isNaN(val) || val === null|| val === 0) ? \"OFF\" : Math.round(val);\n",
              "mock": "2"
            },
            "width": 85,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 38,
            "color": "#fa9023",
            "padding": 0,
            "wrap": "nowrap",
            "left": 415,
            "top": 47,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_9_vcc8iwq",
          "name": "Text 4",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示刹车平衡百分比（带1位小数）\nreturn isNaN($data.brakeBias) ? \"--.-\" : parseFloat($data.brakeBias).toFixed(1);",
              "mock": "55.0"
            },
            "width": 127,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 38,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 500,
            "top": 47,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_10_o5uwiit",
          "name": "Text 5",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数RPM值（自动处理无效数据）\nreturn isNaN($data.rpm) ? \"--\" : Math.round($data.rpm);",
              "mock": "4986"
            },
            "width": 197,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 303,
            "top": 115,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_11_v4baagx",
          "name": "Text 6",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "$scope.bestTime = \"00:00.000\";\n$scope.lastValid = 0;\nfunction format(ms) {\n  if (!Number.isFinite(ms)) return $scope.bestTime;\n  \n  const d = new Date(ms);\n  $scope.lastValid = ms;\n  return `${d.getUTCMinutes().toString().padStart(2,'0')}:` +\n         `${d.getUTCSeconds().toString().padStart(2,'0')}.` +\n         `${d.getUTCMilliseconds().toString().padStart(3,'0')}`;\n}\n\nreturn $scope.bestTime = format($data.bestLapTime);",
              "mock": "1:35.311"
            },
            "width": 287,
            "height": 50,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 48,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 28,
            "top": 142,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_12_k2keaqt",
          "name": "Text 7",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// ===== Run Once 初始化 =====\nif (typeof $scope.lastLap === 'undefined') {\n  $scope.lastLap = {\n    display: \"00:00.000\",\n    raw: 0,\n    valid: false\n  };\n}\n\n// ===== 主显示逻辑 =====\nfunction formatLap(ms) {\n  if (isNaN(parseFloat(ms))) {\n    $scope.lastLap.valid = false;\n    return $scope.lastLap.display;\n  }\n\n  var d = new Date(parseInt(ms));\n  $scope.lastLap.raw = ms;\n  $scope.lastLap.valid = true;\n  \n  return (\n    ('0' + d.getUTCMinutes()).slice(-2) + ':' +\n    ('0' + d.getUTCSeconds()).slice(-2) + '.' +\n    ('00' + d.getUTCMilliseconds()).slice(-3)\n  );\n}\n\nreturn formatLap($data.lastLapTime);",
              "mock": "1:41.397"
            },
            "width": 169,
            "height": 34,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 28,
            "top": 234,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_13_oqn50yn",
          "name": "Text 8",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 强制显示±符号和两位小数（FIA标准格式）\nreturn isNaN($data.gainLoss) ? \"+0.00\" : \n       ($data.gainLoss >= 0 ? \"+\" : \"-\") + Math.abs($data.gainLoss).toFixed(2);",
              "mock": "-2.67"
            },
            "width": 132,
            "height": 43,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "// FIA标准配色方案\nreturn $data.gainLoss > 0 ? \"#FF0000\" :\n       $data.gainLoss < 0 ? \"#00FF00\" :\n       \"#00FF00\";",
              "mock": "#25d939"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 171,
            "top": 240,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_14_to8t788",
          "name": "Text 9",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "return isNaN(parseFloat($data.fuelPerLap))?\"--.-\":parseFloat($data.fuelPerLap).toFixed(1);",
              "mock": "4.2"
            },
            "width": 150,
            "height": 43,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 40,
            "color": {
              "type": "JSExpression",
              "value": "return ($data.fuelPerLap<2.0)?\"#00EAF0\":($data.fuelPerLap<=3.5)?\"#00FF00\":($data.fuelPerLap<=5.0)?\"#FFFF00\":\"#FF0000\";",
              "mock": "#ffffff"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 28,
            "top": 307,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_15_dhq0hu4",
          "name": "Text 10",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数油温（自动处理无效值）\nreturn isNaN($data.waterTemperature) ? \"---\" : Math.round($data.waterTemperature);",
              "mock": "70"
            },
            "width": 67,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 21,
            "top": 391,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_16_n6dn7i6",
          "name": "Text 11",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数油温（自动处理无效值）\nreturn isNaN($data.oilTemperature) ? \"---\" : Math.round($data.oilTemperature);",
              "mock": "77"
            },
            "width": 67,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 88,
            "top": 391,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_17_dsd5210",
          "name": "Text 12",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数圈数（自动处理异常值）\nreturn $data.completedLaps",
              "mock": "13"
            },
            "width": 67,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 155,
            "top": 391,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_18_ot7hwra",
          "name": "Text 13",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示当前名次（自动处理无效值）\nreturn isNaN($data.position) ? \"--\" : $data.position;",
              "mock": "12"
            },
            "width": 67,
            "height": 34,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 222,
            "top": 391,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_19_p9cgl8f",
          "name": "Text 14",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数车速（自动处理无效值）\nreturn isNaN($data.speed) ? \"---\" : Math.round($data.speed);",
              "mock": "200"
            },
            "width": 138,
            "height": 43,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 48,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 331,
            "top": 387,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": "normal"
          }
        },
        {
          "id": "node_6_cou9pth",
          "name": "Text 23",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// Text元件的\"内容(content)\"属性FX：\nreturn $data.gear === 0 ? \"N\" : ($data.gear === -1 ? \"R\" : $data.gear);",
              "mock": "3"
            },
            "width": 169,
            "height": 203,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 240,
            "color": "#ffdf00",
            "padding": 0,
            "wrap": "nowrap",
            "left": 315,
            "top": 155,
            "fontFamily": "Sora",
            "fontStyle": "normal",
            "fontWeight": 600
          }
        },
        {
          "id": "node_22_k4ya93i",
          "name": "Rectangle 9",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 224,
            "height": 81,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 0,
            "top": 0
          }
        },
        {
          "id": "node_23_9jqx7bn",
          "name": "Rectangle 10",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 155,
            "height": 52,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#f53b0d",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": "#000000",
            "left": 145,
            "top": 302
          }
        },
        {
          "id": "node_12_uwjr2qo",
          "name": "Text 28",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureFrontLeft);\nif (isNaN(p)) return \"---\";\nif (p > 100) return p.toFixed(0);\nif (p > 10)  return p.toFixed(1);\nreturn p.toFixed(1) ;",
              "mock": "1.65"
            },
            "width": 91,
            "height": 66,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureFrontLeft);\n// 无效数据 → 灰色\nif (isNaN(p)) return \"#FFFFFF\"; \n// 颜色配置\nlet colors = {\n  low:  \"#00FF00\", \n  mid:  \"#FFFFFF\", \n  high: \"#FF0000\" \n};\n// kPa 区间判断\nif (p > 100) {\n  return p > 120 ? colors.high \n       : p > 110 ? colors.mid \n       : colors.low;\n}\n// PSI 区间判断\nif (p > 10) {\n  return p > 32 ? colors.high \n       : p > 26 ? colors.mid \n       : colors.low;\n}\n// bar 区间判断\nreturn p > 2.2 ? colors.high \n     : p > 1.8 ? colors.mid \n     : colors.low;\n",
              "mock": "#31ff1d"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 475,
            "top": 166,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": 600
          }
        },
        {
          "id": "node_13_wnt7v7l",
          "name": "Text 29",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureFrontRight);\nif (isNaN(p)) return \"---\";\nif (p > 100) return p.toFixed(0);\nif (p > 10)  return p.toFixed(1);\nreturn p.toFixed(1) ;",
              "mock": "1.65"
            },
            "width": 90,
            "height": 66,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureFrontRight);\n// 无效数据 → 灰色\nif (isNaN(p)) return \"#FFFFFF\"; \n// 颜色配置\nlet colors = {\n  low:  \"#00FF00\", \n  mid:  \"#FFFFFF\", \n  high: \"#FF0000\" \n};\n// kPa 区间判断\nif (p > 100) {\n  return p > 120 ? colors.high \n       : p > 110 ? colors.mid \n       : colors.low;\n}\n// PSI 区间判断\nif (p > 10) {\n  return p > 32 ? colors.high \n       : p > 26 ? colors.mid \n       : colors.low;\n}\n// bar 区间判断\nreturn p > 2.2 ? colors.high \n     : p > 1.8 ? colors.mid \n     : colors.low;\n",
              "mock": "#31ff1d"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 698,
            "top": 164,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": 600
          }
        },
        {
          "id": "node_14_qfu3zh7",
          "name": "Text 30",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureRearLeft);\nif (isNaN(p)) return \"---\";\nif (p > 100) return p.toFixed(0);\nif (p > 10)  return p.toFixed(1);\nreturn p.toFixed(1) ;",
              "mock": "1.65"
            },
            "width": 85,
            "height": 53,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureRearLeft);\n// 无效数据 → 灰色\nif (isNaN(p)) return \"#FFFFFF\"; \n// 颜色配置\nlet colors = {\n  low:  \"#00FF00\", \n  mid:  \"#FFFFFF\", \n  high: \"#FF0000\" \n};\n// kPa 区间判断\nif (p > 100) {\n  return p > 120 ? colors.high \n       : p > 110 ? colors.mid \n       : colors.low;\n}\n// PSI 区间判断\nif (p > 10) {\n  return p > 32 ? colors.high \n       : p > 26 ? colors.mid \n       : colors.low;\n}\n// bar 区间判断\nreturn p > 2.2 ? colors.high \n     : p > 1.8 ? colors.mid \n     : colors.low;\n",
              "mock": "#31ff1d"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 484,
            "top": 365,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": 600
          }
        },
        {
          "id": "node_15_dqb8u1f",
          "name": "Text 31",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureRearRight);\nif (isNaN(p)) return \"---\";\nif (p > 100) return p.toFixed(0);\nif (p > 10)  return p.toFixed(1);\nreturn p.toFixed(1) ;",
              "mock": "1.65"
            },
            "width": 91,
            "height": 53,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": {
              "type": "JSExpression",
              "value": "let p = Number($data.tyrePressureRearRight);\n// 无效数据 → 灰色\nif (isNaN(p)) return \"#FFFFFF\"; \n// 颜色配置\nlet colors = {\n  low:  \"#00FF00\", \n  mid:  \"#FFFFFF\", \n  high: \"#FF0000\" \n};\n// kPa 区间判断\nif (p > 100) {\n  return p > 120 ? colors.high \n       : p > 110 ? colors.mid \n       : colors.low;\n}\n// PSI 区间判断\nif (p > 10) {\n  return p > 32 ? colors.high \n       : p > 26 ? colors.mid \n       : colors.low;\n}\n// bar 区间判断\nreturn p > 2.2 ? colors.high \n     : p > 1.8 ? colors.mid \n     : colors.low;\n",
              "mock": "#31ff1d"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 698,
            "top": 365,
            "fontFamily": "Goldman",
            "fontStyle": "normal",
            "fontWeight": 600
          }
        },
        {
          "id": "node_16_xwel85l",
          "name": "Text 32",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数温度值+单位（自动继承颜色）\nreturn Math.round($data.tyreTemperatureFrontRight);",
              "mock": "83"
            },
            "width": 77,
            "height": 29,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "// 单行实现三色温度逻辑\nreturn $data.tyreTemperatureFrontRight <= 80 ? \"#00EAF0\" : ($data.tyreTemperatureFrontRight <= 110 ? \"#00FF00\" : \"#FF0000\");",
              "mock": "#25f854"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 702,
            "top": 226,
            "fontFamily": "Goldman"
          }
        },
        {
          "id": "node_17_20qby0l",
          "name": "Text 33",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数温度值 + ℃单位\nreturn Math.round($data.tyreTemperatureFrontLeft) ;",
              "mock": "72"
            },
            "width": 77,
            "height": 29,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "return ($data.tyreTemperatureFrontLeft <=80)? \"#00EAF0\":($data.tyreTemperatureFrontLeft <=110?\"#00FF00\":\"#FF0000\");",
              "mock": "#25fbe3"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 489,
            "top": 221,
            "fontFamily": "Goldman"
          }
        },
        {
          "id": "node_24_tppd12n",
          "name": "Text 34",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数温度值 + ℃单位\nreturn Math.round($data.tyreTemperatureRearLeft);",
              "mock": "123"
            },
            "width": 80,
            "height": 29,
            "textAlign": "right",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "return ($data.tyreTemperatureRearLeft <=80)? \"#00EAF0\":($data.tyreTemperatureRearLeft <=110?\"#00FF00\":\"#FF0000\");",
              "mock": "#ff0000"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 489,
            "top": 336,
            "fontFamily": "Goldman"
          }
        },
        {
          "id": "node_25_82bv521",
          "name": "Text 35",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "// 显示整数温度值 + ℃单位\nreturn Math.round($data.tyreTemperatureRearRight);",
              "mock": "125"
            },
            "width": 77,
            "height": 29,
            "textAlign": "left",
            "verticalAlign": "center",
            "rotation": "",
            "visible": true,
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "none",
            "___supportRefreshInterval___": true,
            "borderRadius": 0,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "return ($data.tyreTemperatureRearRight <=80)? \"#00EAF0\":($data.tyreTemperatureRearRight <=110?\"#00FF00\":\"#FF0000\");",
              "mock": "#ff0000"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 702,
            "top": 336,
            "fontFamily": "Goldman"
          }
        },
        {
          "id": "node_20_zlbsngn",
          "name": "Rectangle 11",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 24,
            "height": 52,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 8,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "let t=$data.brakeTemperatureFrontLeft\n// 三段式温度区间配色（严格单行表达式）\nreturn (t=$data.brakeTemperatureFrontLeft)>=850?\"#FF0000\":t>=400?\"#34D500\":\"#0042F0\";",
              "mock": "#20ff42"
            },
            "left": 581,
            "top": 204
          }
        },
        {
          "id": "node_21_2pxnq5r",
          "name": "Rectangle 12",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 24,
            "height": 52,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 8,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "let t=$data.brakeTemperatureFrontRight// 三段式温度区间配色（严格单行表达式）\nreturn (t=$data.brakeTemperatureFrontRight)>=850?\"#FF0000\":t>=400?\"#34D500\":\"#0042F0\";",
              "mock": "#20ff42"
            },
            "left": 665,
            "top": 204
          }
        },
        {
          "id": "node_26_8yaj7ln",
          "name": "Rectangle 13",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 24,
            "height": 52,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 8,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "let t=$data.brakeTemperatureRearLeft// 三段式温度区间配色（严格单行表达式）\nreturn (t=$data.brakeTemperatureRearLeft)>=850?\"#FF0000\":t>=400?\"#34D500\":\"#0042F0\";",
              "mock": "#ff0000"
            },
            "left": 581,
            "top": 339
          }
        },
        {
          "id": "node_27_99qljrm",
          "name": "Rectangle 14",
          "componentName": "Rectangle",
          "lifeCycles": {},
          "props": {
            "width": 24,
            "height": 52,
            "rotation": "",
            "visible": true,
            "borderWidth": 2,
            "borderColor": "#ffffff",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 8,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "let t=$data.brakeTemperatureRearRight// 三段式温度区间配色（严格单行表达式）\nreturn (t=$data.brakeTemperatureRearRight)>=850?\"#FF0000\":t>=400?\"#34D500\":\"#0042F0\";",
              "mock": "#ff0000"
            },
            "left": 665,
            "top": 336
          }
        },
        {
          "id": "node_28_cgrs2la",
          "name": "Image 2",
          "componentName": "Image",
          "lifeCycles": {},
          "props": {
            "width": 150,
            "height": 53,
            "rotation": "",
            "visible": false,
            "borderColor": "#f53b0d",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 10,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "objectFit": "contain",
            "left": 362,
            "top": -34,
            "image": "asset://04069750-d6ef-471e-b126-1f8528cfe076"
          }
        },
        {
          "id": "node_31_uz6jfx1",
          "name": "Text 36",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "FUEL LOW",
            "width": 152,
            "height": 49,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "let fuel = $data.fuel;\n\n// 无效数据 → 隐藏\nif (isNaN(fuel)) return false;\n\n// 判断单位：大于 20 基本是 L，小于等于 20 基本是 kg\nif (fuel > 20) {\n  // 当作 L → 小于 10L 警告\n  return fuel < 10;\n} else {\n  // 当作 kg → 小于 7kg 警告\n  return fuel < 7;\n}\n",
              "mock": true
            },
            "borderColor": "#ff4700",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 10,
            "borderWidth": 2,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 30,
            "color": "#ffffff",
            "padding": 0,
            "wrap": "nowrap",
            "left": 560,
            "top": 271,
            "backgroundColor": "#ff2f00fc",
            "fontFamily": "Squada One"
          }
        },
        {
          "id": "node_32_uyzzxmk",
          "name": "Text 37",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": "PIT ",
            "width": 169,
            "height": 56,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.isPitLimiterOn",
              "mock": false
            },
            "borderColor": "#000000",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 10,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 44,
            "color": "#000000",
            "padding": 0,
            "wrap": "nowrap",
            "left": 34,
            "top": 19,
            "backgroundColor": "#ffffff",
            "fontFamily": "Goldman",
            "fontWeight": "bold"
          }
        },
        {
          "id": "node_33_7orwp5b",
          "name": "Text 38",
          "componentName": "Text",
          "lifeCycles": {},
          "props": {
            "value": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"BLACK\" :\n       $data.blueFlag ? \"BLUE\" :\n       $data.checkeredFlag ? \"CHECKERED\" :\n       $data.greenFlag ? \"GREEN\" :\n       $data.orangeFlag ? \"ORANGE\" :\n       $data.redFlag ? \"RED\" :\n       $data.whiteFlag ? \"WHITE\" :\n       $data.yellowFlag ? \"YELLOW\" :\n       \"\";\n",
              "mock": ""
            },
            "width": 171,
            "height": 58,
            "textAlign": "center",
            "verticalAlign": "center",
            "rotation": "",
            "visible": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"BLACK\" :\n       $data.blueFlag ? \"BLUE\" :\n       $data.checkeredFlag ? \"CHECKERED\" :\n       $data.greenFlag ? \"GREEN\" :\n       $data.orangeFlag ? \"ORANGE\" :\n       $data.redFlag ? \"RED\" :\n       $data.whiteFlag ? \"WHITE\" :\n       $data.yellowFlag ? \"YELLOW\" :\n       \"\";\n",
              "mock": true
            },
            "borderColor": "rgba(255, 255, 255, 1)",
            "borderStyle": "solid",
            "___supportRefreshInterval___": true,
            "borderRadius": 10,
            "borderWidth": 0,
            "blinkDelay": 0,
            "blinkEnabled": false,
            "blurRadius": 0,
            "opacity": 100,
            "fontSize": 28,
            "color": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"#FFFFFF\" :  \n       $data.blueFlag ? \"#FFFFFF\" :  \n       $data.checkeredFlag ? \"#000000\" : \n       $data.greenFlag ? \"#000000\" :\n       $data.orangeFlag ? \"#000000\" :  \n       $data.redFlag ? \"#FFFFFF\" :   \n       $data.whiteFlag ? \"#000000\" :  \n       $data.yellowFlag ? \"#000000\" : \n       \"#FFFFFF\";                  \n",
              "mock": "#ffffff"
            },
            "padding": 0,
            "wrap": "nowrap",
            "left": 617,
            "top": 23,
            "backgroundColor": {
              "type": "JSExpression",
              "value": "return $data.blackFlag ? \"#000000\" : \n       $data.blueFlag ? \"#0000FF\" :   \n       $data.checkeredFlag ? \"#FFFFFF\" : \n       $data.greenFlag ? \"#00FF00\" :   \n       $data.orangeFlag ? \"#FFA500\" : \n       $data.redFlag ? \"#FF0000\" :     \n       $data.whiteFlag ? \"#DDDDDD\" :  \n       $data.yellowFlag ? \"#FFFF00\" :  \n       \"#3B3B3B\";                     \n",
              "mock": "#ffffff00"
            },
            "fontFamily": "Goldman",
            "fontWeight": "bold"
          }
        }
      ],
      "roles": [
        "InGame",
        "Idel"
      ]
    }
  ],
  "assets": [
    {
      "id": "04069750-d6ef-471e-b126-1f8528cfe076",
      "name": "企业微信截图_17583629378324",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 409,
        "height": 137
      }
    },
    {
      "id": "global-button-red-pressed",
      "name": "red button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-red",
      "name": "red button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green-pressed",
      "name": "green button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-green",
      "name": "green button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-yellow-pressed",
      "name": "yellow button-pressed",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "global-button-yellow",
      "name": "yellow button",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 100,
        "height": 100
      }
    },
    {
      "id": "e4a5eb0e-34c4-4f2a-9c2d-d27b60173f51",
      "name": "160",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 800,
        "height": 480
      }
    },
    {
      "id": "d4e61377-a39f-48e9-8e24-c2c7b5a31838",
      "name": "screen_720Super",
      "type": "image",
      "ext": ".png",
      "relativePath": "",
      "description": "",
      "props": {
        "width": 640,
        "height": 384
      }
    }
  ],
  "config": {
    "dash_name": "720Super",
    "device_size": [
      {
        "width": 800,
        "height": 480,
        "product_uuid": "0000000000000000",
        "product_name": "generic"
      }
    ],
    "category": {
      "gt": [
        "a1b2c3d4-e5f6-47a8-9b0c-1d2e3f4a5b6c"
      ]
    },
    "telemetry": [
      {
        "pageId": "node_0_pt1ppkg",
        "data": [
          "engineMap",
          "tcLevel",
          "absLevel",
          "brakeBias",
          "rpm",
          "bestLapTime",
          "lastLapTime",
          "gainLoss",
          "fuelPerLap",
          "waterTemperature",
          "oilTemperature",
          "completedLaps",
          "position",
          "speed",
          "gear",
          "tyrePressureFrontLeft",
          "tyrePressureFrontRight",
          "tyrePressureRearLeft",
          "tyrePressureRearRight",
          "tyreTemperatureFrontRight",
          "tyreTemperatureFrontLeft",
          "tyreTemperatureRearLeft",
          "tyreTemperatureRearRight",
          "brakeTemperatureFrontLeft",
          "brakeTemperatureFrontRight",
          "brakeTemperatureRearLeft",
          "brakeTemperatureRearRight",
          "fuel",
          "isPitLimiterOn",
          "blackFlag",
          "blueFlag",
          "checkeredFlag",
          "greenFlag",
          "orangeFlag",
          "redFlag",
          "whiteFlag",
          "yellowFlag"
        ]
      }
    ],
    "width": 800,
    "height": 480
  }
}